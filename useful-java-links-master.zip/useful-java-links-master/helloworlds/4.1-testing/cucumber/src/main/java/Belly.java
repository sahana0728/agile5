/**
 *  Cucumber Hello World
 *
 *  *  To run using "maven test"
 */
public class Belly {
    public void eat(int cukes) {
        for(int i=0; i< cukes; i++ ){
            System.out.println("I'm eating " + (i + 1) + " cuke");
        }
    }
}
