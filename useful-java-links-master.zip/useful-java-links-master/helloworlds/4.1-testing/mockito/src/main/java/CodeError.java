/**
 * This enum for Code Error when buy.
 */
enum CodeError {
    NOT_ENOUGH_FUNDS_BALANCE
}
